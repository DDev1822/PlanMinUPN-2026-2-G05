# Entrega grupal G05 · IMP-008

Abre `index.html` para explorar S11 y S12. Los modelos académicos, controles y relaciones por bloque están en `outputs/`.

Instala `requirements.txt` y ejecuta `python -m src.missions.g05 verificar` para validar los manifiestos. Para reproducir, ejecuta `python -m src.missions.g05 todo`.

Este paquete no contiene historiales ni respuestas individuales. Los supuestos y límites constan en los reportes y la política versionada.
